chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "clearData" && request.origin) {
    chrome.browsingData.remove(
      {
        origins: [request.origin],
        since: 0  // Remove data from the beginning of time
      },
      {
        cookies: true,
        localStorage: true,
        cache: true,
        indexedDB: true,
        serviceWorkers: true
      },
      () => {
        sendResponse({ success: true });
      }
    );
    // Return true to indicate that the response is asynchronous.
    return true;
  }
});
