document.getElementById("clearData").addEventListener("click", async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) {
    alert("No active tab detected.");
    return;
  }
  
  let url = new URL(tab.url);
  let origin = url.origin;
  
  chrome.runtime.sendMessage({ action: "clearData", origin: origin }, (response) => {
    if (response && response.success) {
      // Wait briefly to ensure removal, then reload the tab
      setTimeout(() => chrome.tabs.reload(tab.id), 1000);
    } else {
      alert("Failed to clear data.");
    }
  });
});
